rctmod player set series hoenn @s
advancement grant @s only cobbleverse:gen_3
tellraw @s {"text":"--- Hoenn Series Activated! ---","bold":true,"color":"green"}
tellraw @s [{"text":"You are now ready to challenge the Hoenn Gym Leaders (Gen 3)!","color":"aqua"}]
tellraw @s [{"text":"For more info, check the Official Wiki: ","color":"gray"},{"text":"[CLICK HERE]","bold":true,"color":"yellow","clickEvent":{"action":"open_url","value":"https://www.lumyverse.com/cobbleverse"}}]