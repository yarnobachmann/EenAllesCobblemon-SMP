rctmod player set series johto @s
advancement grant @s only cobbleverse:gen_2
tellraw @s {"text":"--- Johto Series Activated! ---","bold":true,"color":"green"}
tellraw @s [{"text":"You are now ready to challenge the Johto Gym Leaders!","color":"aqua"}]
tellraw @s [{"text":"For more info, check the Official Wiki: ","color":"gray"},{"text":"[CLICK HERE]","bold":true,"color":"yellow","clickEvent":{"action":"open_url","value":"https://www.lumyverse.com/cobbleverse"}}]