rctmod player set series sinnoh @s
advancement grant @s only cobbleverse:gen_4
tellraw @s {"text":"--- Sinnoh Series Activated! ---","bold":true,"color":"green"}
tellraw @s [{"text":"You are now ready to challenge the Sinnoh Gym Leaders!","color":"aqua"}]
tellraw @s [{"text":"For more info, check the Official Wiki: ","color":"gray"},{"text":"[CLICK HERE]","bold":true,"color":"yellow","clickEvent":{"action":"open_url","value":"https://www.lumyverse.com/cobbleverse"}}]