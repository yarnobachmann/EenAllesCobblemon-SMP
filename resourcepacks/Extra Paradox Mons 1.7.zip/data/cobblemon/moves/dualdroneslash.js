({
     num: 9904,
   accuracy: 100,
   basePower: 45,
   category: "Special",
   name: "Dual Droneslash",
   pp: 10,
   priority: 1,
   flags: { protect: 1, mirror: 1, metronome: 1, slicing: 1, distance: 1, },
   multihit: 2,
   secondary: {
   self: {
    chance: 50,
     boosts: {
      spe: -1,
		}
  },
},
   target: "normal",
   type: "Flying",
   contestType: "Cute"
 })
