({
		name: "Draco Gear",
		spritenum: 9994,
		onTakeItem(item, pokemon, source) {
			if ((source && source.baseSpecies.num === 9908) || pokemon.baseSpecies.num === 9908) {
				return false;
			}
			return true;
		},
		onDrive: 'Dragon',
		forcedForme: "wildgene-draco",
		itemUser: ["wildgene-draco"],
		num: 9994,
		gen: 9,
		isNonstandard: "Past",
	})
